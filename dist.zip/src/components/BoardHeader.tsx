import type { ChangeEvent } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ArchiveRestore, Download, FileText, MoreHorizontal, PencilLine, Plus, RefreshCw, Settings2, Trash2, Upload } from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';
import { DEFAULT_DATABASE_SCHEMA, RUNTIME_PROPERTY_TYPES } from '../config/database';
import { useBoardStore } from '../store/boardStore';
import { STATUS_ORDER, type PropertyDefinition } from '../types/board';
import { getBusinessDaysLabel } from '../utils/scheduling';

const UI_SETTINGS_EVENT = 'promanager-ui-settings-updated';
const TELEGRAM_SYNC_CURSOR_KEY = 'promanager-telegram-sync-cursor';

const escapeHtml = (value: string): string =>
  value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');

const formatIsoDateForDisplay = (value: string): string => {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return value;
  return `${match[3]}.${match[2]}.${match[1]}`;
};

const loadUiSettingsFromStorage = () => {
  const defaultLabel = APP_CONFIG.board.dashboardLabel;
  const defaultSubtitle = APP_CONFIG.board.subtitle;

  try {
    const savedLabel = localStorage.getItem(APP_CONFIG.persistence.dashboardLabelStorageKey)?.trim();
    const savedSubtitle = localStorage.getItem(APP_CONFIG.persistence.dashboardSubtitleStorageKey)?.trim();

    return {
      dashboardLabel: savedLabel || defaultLabel,
      dashboardSubtitle: savedSubtitle || defaultSubtitle,
    };
  } catch {
    return {
      dashboardLabel: defaultLabel,
      dashboardSubtitle: defaultSubtitle,
    };
  }
};

const saveUiSettingsToStorage = (dashboardLabel: string, dashboardSubtitle: string): void => {
  try {
    localStorage.setItem(APP_CONFIG.persistence.dashboardLabelStorageKey, dashboardLabel);
    localStorage.setItem(APP_CONFIG.persistence.dashboardSubtitleStorageKey, dashboardSubtitle);
  } catch {
    // Ignore storage issues.
  }

  window.dispatchEvent(new CustomEvent(UI_SETTINGS_EVENT));
};

const readTelegramSyncCursor = (): string | null => {
  try {
    const raw = localStorage.getItem(TELEGRAM_SYNC_CURSOR_KEY)?.trim();
    if (!raw) return null;
    const ms = Date.parse(raw);
    if (!Number.isFinite(ms)) return null;
    return new Date(ms).toISOString();
  } catch {
    return null;
  }
};

const writeTelegramSyncCursor = (iso: string): void => {
  try {
    localStorage.setItem(TELEGRAM_SYNC_CURSOR_KEY, iso);
  } catch {
    // Ignore storage issues.
  }
};

const clearTelegramSyncCursor = (): void => {
  try {
    localStorage.removeItem(TELEGRAM_SYNC_CURSOR_KEY);
  } catch {
    // Ignore storage issues.
  }
};

const syncDatabaseSchemaToServer = async (database: unknown): Promise<void> => {
  const response = await fetch('/api/board/schema', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ database }),
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Schema-Sync fehlgeschlagen (${response.status}): ${detail}`);
  }
};

const transliterateForSlug = (value: string): string =>
  value
    .replaceAll('ä', 'ae')
    .replaceAll('ö', 'oe')
    .replaceAll('ü', 'ue')
    .replaceAll('ß', 'ss')
    .replaceAll('Ä', 'ae')
    .replaceAll('Ö', 'oe')
    .replaceAll('Ü', 'ue');

const slugify = (value: string): string =>
  transliterateForSlug(value)
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9_-]/g, '')
    .replace(/-{2,}/g, '-')
    .replace(/^[-_]+|[-_]+$/g, '');

const parseOptionsInput = (value: string | null): string[] | undefined => {
  if (!value) return undefined;
  const normalized = value
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
  if (!normalized.length) return undefined;
  return Array.from(new Set(normalized));
};

const promptPropertyDraft = (existing?: PropertyDefinition) => {
  const name = window.prompt('Feldname', existing?.name ?? '');
  if (!name) return null;

  const typePrompt = window.prompt(
    `Feldtyp (${RUNTIME_PROPERTY_TYPES.join('/')})`,
    existing?.type ?? RUNTIME_PROPERTY_TYPES[0],
  );
  if (!typePrompt) return null;
  const type = typePrompt.trim().toLowerCase();
  if (!(RUNTIME_PROPERTY_TYPES as readonly string[]).includes(type)) {
    alert(`Ungueltiger Typ. Erlaubt: ${RUNTIME_PROPERTY_TYPES.join(', ')}`);
    return null;
  }

  let options: string[] | undefined;
  if (type === 'select') {
    const optionsInput = window.prompt(
      'Optionen (durch Komma trennen)',
      existing?.options?.join(', ') ?? '',
    );
    options = parseOptionsInput(optionsInput);
  }

  const id = existing?.id ?? slugify(name);
  if (!id) {
    alert('Feld-ID konnte nicht erzeugt werden.');
    return null;
  }

  return {
    id,
    name: name.trim(),
    type: type as Extract<PropertyDefinition['type'], 'text' | 'select' | 'date'>,
    options,
  };
};

const printHtmlViaIframe = (html: string): void => {
  const frame = document.createElement('iframe');
  frame.style.position = 'fixed';
  frame.style.right = '0';
  frame.style.bottom = '0';
  frame.style.width = '0';
  frame.style.height = '0';
  frame.style.border = '0';
  frame.setAttribute('aria-hidden', 'true');
  document.body.appendChild(frame);

  const cleanup = () => {
    window.setTimeout(() => {
      frame.remove();
    }, 250);
  };

  frame.onload = () => {
    const win = frame.contentWindow;
    if (!win) {
      cleanup();
      return;
    }

    win.focus();
    win.print();
    win.onafterprint = cleanup;
  };

  const doc = frame.contentDocument;
  if (!doc) {
    cleanup();
    return;
  }

  doc.open();
  doc.write(html);
  doc.close();
};

export function BoardHeader() {
  const exportState = useBoardStore((s) => s.exportState);
  const importState = useBoardStore((s) => s.importState);
  const importTelegramState = useBoardStore((s) => s.importTelegramState);
  const dedupeBoard = useBoardStore((s) => s.dedupeBoard);
  const cardsById = useBoardStore((s) => s.cardsById);
  const columns = useBoardStore((s) => s.columns);
  const database = useBoardStore((s) => s.database);
  const addPropertyDefinition = useBoardStore((s) => s.addPropertyDefinition);
  const updatePropertyDefinition = useBoardStore((s) => s.updatePropertyDefinition);
  const removePropertyDefinition = useBoardStore((s) => s.removePropertyDefinition);
  const restoreCard = useBoardStore((s) => s.restoreCard);
  const deleteCard = useBoardStore((s) => s.deleteCard);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDetailsElement>(null);

  const [dashboardLabel, setDashboardLabel] = useState<string>(APP_CONFIG.board.dashboardLabel);
  const [dashboardSubtitle, setDashboardSubtitle] = useState<string>(APP_CONFIG.board.subtitle);
  const [isArchiveOpen, setIsArchiveOpen] = useState(false);
  const [isPropertyEditorOpen, setIsPropertyEditorOpen] = useState(false);

  const businessDaysLabel = getBusinessDaysLabel();
  const scheduleLabel = `${APP_CONFIG.scheduling.workdayStart}-${APP_CONFIG.scheduling.workdayEnd} Uhr`;

  const archivedCards = useMemo(
    () =>
      Object.values(cardsById)
        .filter((card) => !!card.hiddenAt)
        .sort((a, b) => (b.hiddenAt ?? '').localeCompare(a.hiddenAt ?? '')),
    [cardsById],
  );

  useEffect(() => {
    const syncFromStorage = () => {
      const settings = loadUiSettingsFromStorage();
      setDashboardLabel(settings.dashboardLabel);
      setDashboardSubtitle(settings.dashboardSubtitle);
    };

    syncFromStorage();
    window.addEventListener(UI_SETTINGS_EVENT, syncFromStorage);

    return () => window.removeEventListener(UI_SETTINGS_EVENT, syncFromStorage);
  }, []);

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      try {
        await syncDatabaseSchemaToServer(database);
      } catch (error) {
        if (cancelled) return;
        const message = error instanceof Error ? error.message : 'Schema-Sync fehlgeschlagen.';
        console.warn(message);
      }
    };

    void run();
    return () => {
      cancelled = true;
    };
  }, [database]);

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.open) return;
      if (!(event.target instanceof Node)) return;
      if (menuRef.current.contains(event.target)) return;
      menuRef.current.open = false;
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      if (!menuRef.current?.open) return;
      menuRef.current.open = false;
    };

    window.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('keydown', handleEscape);
    return () => {
      window.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('keydown', handleEscape);
    };
  }, []);

  const closeMenu = () => {
    if (menuRef.current) menuRef.current.open = false;
  };

  const handleEditDashboardLabel = () => {
    const nextLabel = window.prompt('Dashboard-Titel', dashboardLabel)?.trim();
    if (!nextLabel) return;

    const nextSubtitleRaw = window.prompt('Dashboard-Untertitel', dashboardSubtitle);
    const nextSubtitle = (nextSubtitleRaw ?? dashboardSubtitle).trim() || APP_CONFIG.board.subtitle;

    setDashboardLabel(nextLabel);
    setDashboardSubtitle(nextSubtitle);
    saveUiSettingsToStorage(nextLabel, nextSubtitle);
  };

  const handleAddProperty = () => {
    const draft = promptPropertyDraft();
    if (!draft) return;
    addPropertyDefinition(draft);
  };

  const handleEditProperty = (property: PropertyDefinition) => {
    const draft = promptPropertyDraft(property);
    if (!draft) return;
    updatePropertyDefinition(draft);
  };

  const handleDeleteProperty = (property: PropertyDefinition) => {
    if (property.system || property.required) return;
    const ok = window.confirm(`Feld "${property.name}" loeschen?`);
    if (!ok) return;
    removePropertyDefinition(property.id);
  };

  const handleTelegramSync = async () => {
    try {
      const removedBeforeSync = dedupeBoard();
      await syncDatabaseSchemaToServer(database);
      const nowIso = new Date().toISOString();
      const cursor = readTelegramSyncCursor();
      const hasLocalCards = Object.keys(cardsById).length > 0;

      if (!cursor && hasLocalCards) {
        writeTelegramSyncCursor(nowIso);
        if (removedBeforeSync > 0) {
          alert(
            `Telegram Sync initialisiert. ${removedBeforeSync} lokale Dublette(n) bereinigt. Ab jetzt werden nur neue Telegram-Importe synchronisiert.`,
          );
        } else {
          alert('Telegram Sync initialisiert. Ab jetzt werden nur neue Telegram-Importe synchronisiert.');
        }
        return;
      }

      const query = cursor ? `?since=${encodeURIComponent(cursor)}` : '';
      const response = await fetch(`/api/board/state${query}`);
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`Sync fehlgeschlagen (${response.status}): ${detail}`);
      }

      const payload = await response.text();
      const added = importTelegramState(payload);
      writeTelegramSyncCursor(nowIso);

      if (added > 0 && removedBeforeSync > 0) {
        alert(`${added} Telegram-Karte(n) synchronisiert. ${removedBeforeSync} Dublette(n) bereinigt.`);
      } else if (added > 0) {
        alert(`${added} Telegram-Karte(n) synchronisiert.`);
      } else if (removedBeforeSync > 0) {
        alert(`Keine neuen Telegram-Karten gefunden. ${removedBeforeSync} Dublette(n) bereinigt.`);
      } else {
        alert('Keine neuen Telegram-Karten gefunden.');
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Telegram-Sync fehlgeschlagen.';
      alert(message);
    }
  };

  const handleExportJson = () => {
    const data = exportState();
    const blob = new Blob([data], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `kanban-backup-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
    a.click();

    URL.revokeObjectURL(url);
  };

  const handlePdfExport = () => {
    const uiSettings = loadUiSettingsFromStorage();

    const statusSections = STATUS_ORDER.map((status) => {
      const ids = columns[status] ?? [];
      const cards = ids
        .map((id) => cardsById[id])
        .filter((card): card is NonNullable<(typeof cardsById)[string]> => !!card && !card.hiddenAt);

      const cardHtml = cards.length
        ? cards
            .map((card) => {
              const commentsHtml = card.comments.length
                ? `<ul>${[...card.comments]
                    .reverse()
                    .map(
                      (comment) =>
                        `<li><strong>${escapeHtml(comment.user)}</strong> (${new Date(comment.createdAt).toLocaleString('de-AT')}): ${escapeHtml(comment.text)}</li>`,
                    )
                    .join('')}</ul>`
                : '<p class="muted">Keine Kommentare</p>';

              const historyHtml = card.history.length
                ? `<ul>${[...card.history]
                    .reverse()
                    .map(
                      (entry) =>
                        `<li>${escapeHtml(entry.from)} -> ${escapeHtml(entry.to)} (${new Date(entry.movedAt).toLocaleString('de-AT')}, ${escapeHtml(entry.movedBy)})</li>`,
                    )
                    .join('')}</ul>`
                : '<p class="muted">Kein Status-Verlauf</p>';

              return `
                <article class="card">
                  <h3>${escapeHtml(card.title)}</h3>
                  <table>
                    <tr><th>Status</th><td>${escapeHtml(card.status)}</td></tr>
                    <tr><th>Quelle</th><td>${escapeHtml(card.sources.join(', ') || '-')}</td></tr>
                    <tr><th>Datum</th><td>${escapeHtml(card.date ? formatIsoDateForDisplay(card.date) : '-')}</td></tr>
                    <tr><th>Adresse</th><td>${escapeHtml(card.address ?? '-')}</td></tr>
                    <tr><th>Ort</th><td>${escapeHtml(card.location ?? '-')}</td></tr>
                    <tr><th>Telefon</th><td>${escapeHtml(card.phone ?? '-')}</td></tr>
                  </table>
                  <h4>Kommentare</h4>
                  ${commentsHtml}
                  <h4>Status-Verlauf</h4>
                  ${historyHtml}
                </article>
              `;
            })
            .join('')
        : '<p class="muted">Keine Karten in dieser Spalte.</p>';

      return `
        <section>
          <h2>${escapeHtml(status)}</h2>
          ${cardHtml}
        </section>
      `;
    }).join('');

    const archivedHtml = archivedCards.length
      ? `<section><h2>Archiv</h2>${archivedCards
          .map(
            (card) =>
              `<p><strong>${escapeHtml(card.title)}</strong> - archiviert am ${escapeHtml(
                card.hiddenAt ? new Date(card.hiddenAt).toLocaleString('de-AT') : '-',
              )}</p>`,
          )
          .join('')}</section>`
      : '';

    const html = `
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(uiSettings.dashboardLabel)} - PDF Export</title>
  <style>
    @page { size: A4; margin: 12mm; }
    body { font-family: Arial, sans-serif; color: #0f172a; font-size: 11pt; line-height: 1.35; }
    h1 { margin: 0 0 2mm 0; font-size: 18pt; }
    .subtitle { margin: 0 0 6mm 0; color: #475569; font-size: 10pt; }
    h2 { margin: 6mm 0 3mm; font-size: 13pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 1mm; }
    h3 { margin: 0 0 2mm 0; font-size: 11pt; }
    h4 { margin: 3mm 0 1.5mm 0; font-size: 10pt; color: #1e293b; }
    .card { border: 1px solid #cbd5e1; border-radius: 6px; padding: 3mm; margin-bottom: 3mm; page-break-inside: avoid; }
    .muted { color: #64748b; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 2mm; }
    th, td { border-bottom: 1px solid #e2e8f0; padding: 1.2mm 1.5mm; text-align: left; vertical-align: top; }
    th { width: 28mm; color: #475569; font-weight: 600; }
    ul { margin: 0; padding-left: 5mm; }
    li { margin-bottom: 1mm; }
  </style>
</head>
<body>
  <h1>${escapeHtml(uiSettings.dashboardLabel)}</h1>
  <p class="subtitle">${escapeHtml(uiSettings.dashboardSubtitle)} | Export: ${escapeHtml(new Date().toLocaleString('de-AT'))}</p>
  ${statusSections}
  ${archivedHtml}
</body>
</html>`;

    const popup = window.open('about:blank', '_blank');
    if (popup) {
      popup.document.open();
      popup.document.write(html);
      popup.document.close();
      popup.focus();

      setTimeout(() => {
        popup.print();
      }, 250);
      return;
    }

    // Popup blocked: fallback without new window.
    printHtmlViaIframe(html);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImportFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      importState(text);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Import fehlgeschlagen.';
      alert(msg);
    } finally {
      event.target.value = '';
    }
  };

  const handleResetTelegramSync = () => {
    clearTelegramSyncCursor();
    alert('Telegram Sync-Cursor wurde zurueckgesetzt.');
  };

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-gray-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex w-full max-w-[1500px] flex-col gap-3 px-3 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:py-4">
          <div className="min-w-0">
            <h1 className="text-2xl font-bold tracking-tight text-gray-900 sm:text-4xl">{dashboardLabel}</h1>
            <p className="mt-1 text-xs text-gray-500 sm:text-sm">{dashboardSubtitle}</p>

            <div className="mt-2 flex flex-wrap items-center gap-1.5 text-xs text-gray-600">
              <span className="rounded-full border border-gray-200 bg-white px-2 py-1">Arbeitstage: {businessDaysLabel}</span>
              <span className="rounded-full border border-gray-200 bg-white px-2 py-1">Arbeitszeit: {scheduleLabel}</span>
              <span className="rounded-full border border-gray-200 bg-white px-2 py-1">
                Reminder: {APP_CONFIG.scheduling.reminderHoursBefore}h vorher
              </span>
            </div>
          </div>

          <div className="flex w-full items-center justify-end sm:w-auto">
            <details ref={menuRef} className="relative">
              <summary className="list-none cursor-pointer rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                <span className="inline-flex items-center gap-2">
                  <MoreHorizontal className="h-4 w-4" />
                  Menue
                </span>
              </summary>

              <div className="absolute right-0 z-20 mt-1 w-64 max-w-[calc(100vw-2rem)] rounded-lg border border-gray-200 bg-white p-1 shadow-lg">
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handleEditDashboardLabel();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <PencilLine className="h-4 w-4" />
                  Beschriftung
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    setIsPropertyEditorOpen(true);
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <Settings2 className="h-4 w-4" />
                  Eigenschaften
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    setIsArchiveOpen(true);
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <ArchiveRestore className="h-4 w-4" />
                  Archiv ({archivedCards.length})
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handleTelegramSync();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <RefreshCw className="h-4 w-4" />
                  Telegram Sync
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handleResetTelegramSync();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <RefreshCw className="h-4 w-4" />
                  Telegram Sync reset
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handleExportJson();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <Download className="h-4 w-4" />
                  Export JSON
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handlePdfExport();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <FileText className="h-4 w-4" />
                  Export PDF (A4)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    handleImportClick();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  <Upload className="h-4 w-4" />
                  Import JSON
                </button>
              </div>
            </details>

            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={handleImportFile}
            />
          </div>
        </div>
      </header>

      {isArchiveOpen ? (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/30 p-4" onClick={() => setIsArchiveOpen(false)}>
          <div
            className="max-h-[80vh] w-full max-w-3xl overflow-y-auto rounded-xl border border-gray-200 bg-white p-4 shadow-2xl sm:p-5"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-gray-900">Archivierte Karten</h2>
              <button
                type="button"
                onClick={() => setIsArchiveOpen(false)}
                className="rounded-md border border-gray-200 px-2 py-1 text-sm text-gray-600 hover:bg-gray-50"
              >
                Schliessen
              </button>
            </div>

            {archivedCards.length === 0 ? (
              <p className="text-sm text-gray-500">Keine archivierten Karten.</p>
            ) : (
              <div className="space-y-2">
                {archivedCards.map((card) => (
                  <div key={card.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-gray-200 p-3">
                    <div>
                      <p className="text-sm font-semibold text-gray-900">{card.title}</p>
                      <p className="text-xs text-gray-500">
                        Archiviert: {card.hiddenAt ? new Date(card.hiddenAt).toLocaleString('de-AT') : '-'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => restoreCard(card.id)}
                        className="inline-flex min-h-9 items-center gap-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                      >
                        <ArchiveRestore className="h-3.5 w-3.5" />
                        Wiederherstellen
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const ok = window.confirm('Karte endgueltig loeschen?');
                          if (!ok) return;
                          deleteCard(card.id);
                        }}
                        className="inline-flex min-h-9 items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-100"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Loeschen
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : null}

      {isPropertyEditorOpen ? (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/30 p-4" onClick={() => setIsPropertyEditorOpen(false)}>
          <div
            className="max-h-[80vh] w-full max-w-3xl overflow-y-auto rounded-xl border border-gray-200 bg-white p-4 shadow-2xl sm:p-5"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-gray-900">Eigenschaften</h2>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddProperty}
                  className="inline-flex min-h-9 items-center gap-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Feld hinzufuegen
                </button>
                <button
                  type="button"
                  onClick={() => setIsPropertyEditorOpen(false)}
                  className="rounded-md border border-gray-200 px-2 py-1 text-sm text-gray-600 hover:bg-gray-50"
                >
                  Schliessen
                </button>
              </div>
            </div>

            <div className="space-y-2">
              {(database?.properties ?? DEFAULT_DATABASE_SCHEMA.properties).map((property) => (
                <div key={property.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-gray-200 p-3">
                  <div>
                    <p className="text-sm font-semibold text-gray-900">
                      {property.name} <span className="text-xs font-normal text-gray-500">({property.type})</span>
                    </p>
                    <p className="text-xs text-gray-500">
                      id: {property.id}
                      {property.options?.length ? ` | Optionen: ${property.options.join(', ')}` : ''}
                      {property.system ? ' | Systemfeld' : ''}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleEditProperty(property)}
                      className="inline-flex min-h-9 items-center gap-1 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                    >
                      <PencilLine className="h-3.5 w-3.5" />
                      Bearbeiten
                    </button>
                    <button
                      type="button"
                      disabled={property.system || property.required}
                      onClick={() => handleDeleteProperty(property)}
                      className="inline-flex min-h-9 items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Loeschen
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
