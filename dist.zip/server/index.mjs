import crypto from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = Number(process.env.TELEGRAM_MVP_PORT ?? 8787);
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? '';
const WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET ?? '';
const HOST = process.env.TELEGRAM_MVP_HOST ?? '0.0.0.0';
const LLM_ENABLED = ['1', 'true', 'yes', 'on'].includes(String(process.env.LLM_ENABLED ?? '0').toLowerCase());
const LLM_MIN_CONFIDENCE = Math.max(0, Math.min(1, Number(process.env.LLM_MIN_CONFIDENCE ?? 0.7)));
const LLM_STRATEGY = ['dominant', 'hybrid', 'fallback'].includes(String(process.env.LLM_STRATEGY ?? 'dominant').toLowerCase())
  ? String(process.env.LLM_STRATEGY ?? 'dominant').toLowerCase()
  : 'dominant';
const LLM_REPAIR_PASS = ['1', 'true', 'yes', 'on'].includes(String(process.env.LLM_REPAIR_PASS ?? '1').toLowerCase());
const LLM_REPAIR_MIN_CONFIDENCE = Math.max(0, Math.min(1, Number(process.env.LLM_REPAIR_MIN_CONFIDENCE ?? 0.82)));
const LLM_REPAIR_MAX_TRIES = Math.max(1, Math.min(3, Number(process.env.LLM_REPAIR_MAX_TRIES ?? 2)));
const IMPORT_GUARDRAIL_CONFIDENCE = Math.max(0, Math.min(1, Number(process.env.IMPORT_GUARDRAIL_CONFIDENCE ?? 0.65)));
const OPENAI_API_KEY = process.env.OPENAI_API_KEY ?? '';
const OPENAI_BASE_URL = (process.env.OPENAI_BASE_URL ?? 'https://api.openai.com/v1').replace(/\/+$/, '');
const OPENAI_MODEL = process.env.OPENAI_MODEL ?? 'gpt-4.1-mini';
const LLM_TIMEOUT_MS = Math.max(2_000, Number(process.env.LLM_TIMEOUT_MS ?? 12_000));
const AGENT_ENABLED = ['1', 'true', 'yes', 'on'].includes(String(process.env.AGENT_ENABLED ?? '1').toLowerCase());
const AGENT_REQUIRED_FIELDS_RAW = String(process.env.AGENT_REQUIRED_FIELDS ?? 'date,location,address,uhrzeit');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, 'data');
const STATE_PATH = path.join(DATA_DIR, 'state.json');

const APP_DEFAULTS = {
  fallbackStatus: 'Eingang / Anfrage',
  fallbackSource: 'E-Mail',
  actorName: 'Telegram Bot',
  newCardTitle: 'Neue Seite',
  dashboardLabel: 'Projekte Firma 2026',
  dashboardSubtitle: 'Service Management Dashboard',
};

const CARD_PROPERTY_IDS = {
  title: 'title',
  status: 'status',
  sources: 'sources',
  address: 'address',
  location: 'location',
  phone: 'phone',
  date: 'date',
};

const DEFAULT_STATUS_ORDER = ['Eingang / Anfrage', 'Warteschlange', 'Terminiert', 'Erledigt'];

const DEFAULT_DATABASE = {
  id: 'service-card-db',
  name: 'Service Cards',
  properties: [
    { id: CARD_PROPERTY_IDS.title, name: 'Titel', type: 'text', required: true, system: true },
    {
      id: CARD_PROPERTY_IDS.status,
      name: 'Status',
      type: 'select',
      required: true,
      system: true,
      options: [...DEFAULT_STATUS_ORDER],
    },
    { id: CARD_PROPERTY_IDS.address, name: 'Adresse', type: 'text', system: true },
    { id: CARD_PROPERTY_IDS.location, name: 'Ort', type: 'text', system: true },
    { id: CARD_PROPERTY_IDS.phone, name: 'Telefon', type: 'text', system: true },
    { id: CARD_PROPERTY_IDS.date, name: 'Datum', type: 'date', system: true },
  ],
};

const toNowIso = () => new Date().toISOString();
const randomId = (prefix) => `${prefix}_${crypto.randomUUID().replace(/-/g, '')}`;

const normalizeKey = (value) =>
  String(value ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');

const transliterateForSlug = (value) =>
  String(value ?? '')
    .replaceAll('ä', 'ae')
    .replaceAll('ö', 'oe')
    .replaceAll('ü', 'ue')
    .replaceAll('ß', 'ss')
    .replaceAll('Ä', 'ae')
    .replaceAll('Ö', 'oe')
    .replaceAll('Ü', 'ue');

const slugify = (value) =>
  transliterateForSlug(value)
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9_-]/g, '')
    .replace(/-{2,}/g, '-')
    .replace(/^[-_]+|[-_]+$/g, '');

const makeEmptyColumns = (statuses) =>
  statuses.reduce((acc, status) => {
    acc[status] = [];
    return acc;
  }, {});

const createDefaultBoard = () => ({
  schemaVersion: 2,
  cardsById: {},
  columns: makeEmptyColumns(DEFAULT_STATUS_ORDER),
  database: {
    ...DEFAULT_DATABASE,
    properties: DEFAULT_DATABASE.properties.map((property) => ({ ...property, options: property.options?.slice() })),
  },
});

const createDefaultState = () => ({
  version: 1,
  board: createDefaultBoard(),
  pending: {},
  conversations: {},
  audit: [],
  lastUpdateId: -1,
});

const ensureStateShape = (raw) => {
  if (!raw || typeof raw !== 'object') return createDefaultState();
  const fallback = createDefaultState();

  const board = raw.board && typeof raw.board === 'object' ? raw.board : fallback.board;
  const cardsById = board.cardsById && typeof board.cardsById === 'object' ? board.cardsById : {};

  const statusKeys = Object.keys(board.columns && typeof board.columns === 'object' ? board.columns : {});
  const statuses = statusKeys.length ? statusKeys : DEFAULT_STATUS_ORDER;
  const columns = makeEmptyColumns(statuses);
  for (const status of statuses) {
    const rawIds = board.columns?.[status];
    columns[status] = Array.isArray(rawIds) ? rawIds.filter((id) => typeof id === 'string') : [];
  }

  const database =
    board.database && typeof board.database === 'object' && Array.isArray(board.database.properties)
      ? {
          id: String(board.database.id ?? DEFAULT_DATABASE.id),
          name: String(board.database.name ?? DEFAULT_DATABASE.name),
          properties: board.database.properties
            .filter((property) => property && typeof property === 'object')
            .map((property) => ({
              id: slugify(property.id),
              name: String(property.name ?? property.id ?? 'Feld'),
              type: ['text', 'select', 'date'].includes(property.type) ? property.type : 'text',
              required: Boolean(property.required),
              system: Boolean(property.system),
              options: Array.isArray(property.options)
                ? Array.from(new Set(property.options.map((option) => String(option).trim()).filter(Boolean)))
                : undefined,
            }))
            .filter((property) => property.id),
        }
      : fallback.board.database;

  const pending = raw.pending && typeof raw.pending === 'object' ? raw.pending : {};
  const conversations = raw.conversations && typeof raw.conversations === 'object' ? raw.conversations : {};
  const audit = Array.isArray(raw.audit) ? raw.audit : [];
  const lastUpdateId = Number.isInteger(raw.lastUpdateId) ? raw.lastUpdateId : -1;

  const next = {
    version: 1,
    board: {
      schemaVersion: 2,
      cardsById,
      columns,
      database,
    },
    pending,
    conversations,
    audit,
    lastUpdateId,
  };

  for (const required of DEFAULT_DATABASE.properties) {
    if (!next.board.database.properties.some((property) => property.id === required.id)) {
      next.board.database.properties.push({ ...required, options: required.options?.slice() });
    }
  }

  return next;
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 2_000_000) {
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });

const sendJson = (res, status, payload) => {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end(JSON.stringify(payload));
};

const isObject = (value) => typeof value === 'object' && value !== null;

const toIsoLocalDate = (date) =>
  `${date.getFullYear().toString().padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(
    date.getDate(),
  ).padStart(2, '0')}`;

const trimTrailingPunctuation = (value) => String(value ?? '').trim().replace(/[\s,;:.!?]+$/g, '').trim();

const parseIsoDate = (value) => {
  const trimmed = trimTrailingPunctuation(value).replace(/\s*([./-])\s*/g, '$1');
  if (!trimmed) return null;

  const normalized = normalizeKey(trimmed);
  if (normalized.includes('uebermorgen') || normalized.includes('ubermorgen')) {
    const date = new Date();
    date.setDate(date.getDate() + 2);
    return toIsoLocalDate(date);
  }
  if (normalized.includes('heute')) {
    return toIsoLocalDate(new Date());
  }
  if (normalized.includes('morgen')) {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    return toIsoLocalDate(date);
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    const [y, m, d] = trimmed.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCFullYear() === y && dt.getUTCMonth() + 1 === m && dt.getUTCDate() === d) return trimmed;
  }

  const legacy = /^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})$/.exec(trimmed);
  if (!legacy) return null;

  const day = Number(legacy[1]);
  const month = Number(legacy[2]);
  const year = Number(legacy[3].length === 2 ? `20${legacy[3]}` : legacy[3]);
  const dt = new Date(Date.UTC(year, month - 1, day));
  if (dt.getUTCFullYear() !== year || dt.getUTCMonth() + 1 !== month || dt.getUTCDate() !== day) return null;
  return `${year.toString().padStart(4, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
};

const GERMAN_HOUR_WORDS = {
  null: null,
  zero: 0,
  ein: 1,
  eins: 1,
  eine: 1,
  zwei: 2,
  drei: 3,
  vier: 4,
  fuenf: 5,
  funf: 5,
  sechs: 6,
  sieben: 7,
  acht: 8,
  neun: 9,
  zehn: 10,
  elf: 11,
  zwoelf: 12,
  zwolf: 12,
  dreizehn: 13,
  vierzehn: 14,
  fuenfzehn: 15,
  funfzehn: 15,
  sechzehn: 16,
  siebzehn: 17,
  achtzehn: 18,
  neunzehn: 19,
  zwanzig: 20,
  einundzwanzig: 21,
  zweiundzwanzig: 22,
  dreiundzwanzig: 23,
  vierundzwanzig: 24,
};

const parseHourToken = (value) => {
  const trimmed = String(value ?? '').trim();
  if (!trimmed) return null;
  if (/^\d{1,2}$/.test(trimmed)) {
    const n = Number(trimmed);
    return n >= 0 && n <= 24 ? n : null;
  }

  const normalized = normalizeKey(trimmed);
  if (normalized in GERMAN_HOUR_WORDS) return GERMAN_HOUR_WORDS[normalized];
  return null;
};

const formatTimeLabel = (hours, minutes) => {
  const safeHours = ((Number(hours) % 24) + 24) % 24;
  const safeMinutes = Math.max(0, Math.min(59, Number(minutes)));
  return `${String(safeHours).padStart(2, '0')}:${String(safeMinutes).padStart(2, '0')} Uhr`;
};

const normalizeTimeValue = (value) => {
  const raw = trimTrailingPunctuation(value);
  if (!raw) return null;
  const lower = raw.toLowerCase();

  const hhmmRegex = /\b([01]?\d|2[0-3])[:.]([0-5]\d)\b/g;
  for (const match of lower.matchAll(hhmmRegex)) {
    const index = match.index ?? 0;
    const full = match[0] ?? '';
    const before = lower.slice(Math.max(0, index - 12), index);
    const after = lower.slice(index + full.length, index + full.length + 8);
    if (/(datum|date)\s*[:=]?\s*$/i.test(before)) continue;
    if (/^\s*[./-]\s*\d{2,4}/.test(after)) continue;
    return formatTimeLabel(Number(match[1]), Number(match[2]));
  }

  const withUhr = /\b([01]?\d|2[0-3])(?:[:. ]([0-5]\d))?\s*uhr\b/.exec(lower);
  if (withUhr) return formatTimeLabel(Number(withUhr[1]), Number(withUhr[2] ?? 0));

  const quarterAfter = /\bviertel\s+nach\s+([a-z0-9äöüß]+)\b/i.exec(lower);
  if (quarterAfter) {
    const hour = parseHourToken(quarterAfter[1]);
    if (hour !== null) return formatTimeLabel(hour, 15);
  }

  const quarterBefore = /\bviertel\s+vor\s+([a-z0-9äöüß]+)\b/i.exec(lower);
  if (quarterBefore) {
    const hour = parseHourToken(quarterBefore[1]);
    if (hour !== null) return formatTimeLabel(hour - 1, 45);
  }

  const half = /\bhalb\s+([a-z0-9äöüß]+)\b/i.exec(lower);
  if (half) {
    const hour = parseHourToken(half[1]);
    if (hour !== null) return formatTimeLabel(hour - 1, 30);
  }

  const threeQuarter = /\bdreiviertel\s+([a-z0-9äöüß]+)\b/i.exec(lower);
  if (threeQuarter) {
    const hour = parseHourToken(threeQuarter[1]);
    if (hour !== null) return formatTimeLabel(hour - 1, 45);
  }

  const spoken = /\bum\s+([a-z0-9äöüß]+)(?:\s*uhr)?\b/i.exec(lower);
  if (spoken) {
    const hour = parseHourToken(spoken[1]);
    if (hour !== null) return formatTimeLabel(hour, 0);
  }

  return null;
};

const isLikelyTimeProperty = (property) => {
  if (!property?.id) return false;
  const idKey = normalizeKey(property.id);
  const nameKey = normalizeKey(property.name ?? '');
  return (
    idKey.includes('uhrzeit') ||
    idKey === 'zeit' ||
    idKey.includes('time') ||
    nameKey.includes('uhrzeit') ||
    nameKey === 'zeit' ||
    nameKey.includes('time')
  );
};

const parseSelectValue = (value, options) => {
  const trimmed = String(value ?? '').trim();
  if (!trimmed) return options[0] ?? '';
  const exact = options.find((option) => option.toLowerCase() === trimmed.toLowerCase());
  if (exact) return exact;

  const normalizedTarget = normalizeKey(trimmed);
  const byNormalized = options.find((option) => normalizeKey(option) === normalizedTarget);
  if (byNormalized) return byNormalized;

  const byContains = options.find((option) => normalizeKey(option).includes(normalizedTarget));
  return byContains ?? options[0] ?? trimmed;
};

const getSelectOptionsForProperty = (property, columns) =>
  property.id === CARD_PROPERTY_IDS.status
    ? Object.keys(columns)
    : Array.isArray(property.options)
      ? property.options
      : [];

const applyMandatoryValueDefaults = (values, columns, titleSeedLines) => {
  const next = { ...values };

  if (!next[CARD_PROPERTY_IDS.title]) {
    next[CARD_PROPERTY_IDS.title] = titleSeedLines[0]
      ? titleSeedLines[0].slice(0, 140)
      : APP_DEFAULTS.newCardTitle;
  }

  const statuses = Object.keys(columns);
  const fallbackStatus = statuses.includes(APP_DEFAULTS.fallbackStatus) ? APP_DEFAULTS.fallbackStatus : statuses[0];
  if (!next[CARD_PROPERTY_IDS.status]) next[CARD_PROPERTY_IDS.status] = fallbackStatus;
  if (!statuses.includes(next[CARD_PROPERTY_IDS.status])) next[CARD_PROPERTY_IDS.status] = fallbackStatus;

  if (!(CARD_PROPERTY_IDS.date in next)) next[CARD_PROPERTY_IDS.date] = null;
  if (!(CARD_PROPERTY_IDS.address in next)) next[CARD_PROPERTY_IDS.address] = '';
  if (!(CARD_PROPERTY_IDS.location in next)) next[CARD_PROPERTY_IDS.location] = '';
  if (!(CARD_PROPERTY_IDS.phone in next)) next[CARD_PROPERTY_IDS.phone] = '';

  return next;
};

const calculateRuleConfidence = (stats, values) => {
  const structuredCount = Math.max(1, stats.structuredLines);
  const mappedRatio = stats.mappedLines / structuredCount;
  let score = stats.structuredLines === 0 ? 0.45 : 0.4 + mappedRatio * 0.4;
  if (stats.heuristicMatches) score += Math.min(0.2, stats.heuristicMatches * 0.05);
  if (values[CARD_PROPERTY_IDS.title]) score += 0.1;
  if (values[CARD_PROPERTY_IDS.status]) score += 0.05;
  if (values[CARD_PROPERTY_IDS.date]) score += 0.05;
  return Math.max(0, Math.min(0.95, Number(score.toFixed(2))));
};

const parseMetadataFromRaw = (raw) => {
  if (!isObject(raw)) return {};
  const metadata = {};
  if (typeof raw.comment === 'string') metadata.comment = raw.comment.trim();
  if (typeof raw.source === 'string') metadata.source = raw.source.trim();
  return metadata;
};

const toUnmappedArray = (raw) => {
  if (!Array.isArray(raw)) return [];
  return raw.filter((value) => typeof value === 'string').map((value) => value.trim()).filter(Boolean);
};

const findRawValueForProperty = (rawValues, property) => {
  if (!isObject(rawValues)) return undefined;
  if (property.id in rawValues) return rawValues[property.id];

  const targetKeys = [normalizeKey(property.id), normalizeKey(property.name)];
  for (const [key, value] of Object.entries(rawValues)) {
    const normalized = normalizeKey(key);
    if (targetKeys.includes(normalized)) return value;
  }
  return undefined;
};

const sanitizeValuesBySchema = (rawValues, baselineValues, database, columns, textLines) => {
  const values = {};
  for (const property of database.properties) {
    const candidate = findRawValueForProperty(rawValues, property);
    if (candidate === undefined) {
      if (property.id in baselineValues) values[property.id] = baselineValues[property.id];
      continue;
    }

    if (property.type === 'date') {
      values[property.id] = parseIsoDate(candidate) ?? null;
      continue;
    }

    if (property.type === 'select') {
      values[property.id] = parseSelectValue(candidate, getSelectOptionsForProperty(property, columns));
      continue;
    }

    if (isLikelyTimeProperty(property)) {
      const normalizedTime = normalizeTimeValue(candidate);
      values[property.id] = normalizedTime ?? String(candidate).trim();
      continue;
    }

    values[property.id] = String(candidate).trim();
  }

  return applyMandatoryValueDefaults({ ...baselineValues, ...values }, columns, textLines);
};

const parseConfidence = (value, fallback) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(0, Math.min(1, parsed));
};

const getAgentRequiredFieldKeys = () =>
  AGENT_REQUIRED_FIELDS_RAW.split(',')
    .map((entry) => normalizeKey(entry))
    .filter(Boolean);

const isMissingValueForProperty = (property, value) => {
  if (value === null || value === undefined) return true;
  if (property?.type === 'date') return !(typeof value === 'string' && value.trim());
  if (property?.type === 'select') return !(typeof value === 'string' && value.trim());
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  return false;
};

const parseValueForProperty = (property, rawValue, columns) => {
  const text = trimTrailingPunctuation(rawValue);
  if (!text) return { ok: false, message: 'Leerer Wert.' };

  if (property.type === 'date') {
    const parsedDate = parseIsoDate(text) ?? extractIsoDateFromText(text);
    if (!parsedDate) {
      return { ok: false, message: 'Bitte Datum als TT.MM.JJJJ oder YYYY-MM-DD angeben.' };
    }
    return { ok: true, value: parsedDate };
  }

  if (property.type === 'select') {
    const options = getSelectOptionsForProperty(property, columns);
    return { ok: true, value: parseSelectValue(text, options) };
  }

  if (isLikelyTimeProperty(property)) {
    const normalized = normalizeTimeValue(text);
    if (!normalized) {
      return { ok: false, message: 'Bitte Uhrzeit als HH:mm, "15 Uhr", "halb drei" etc. angeben.' };
    }
    return { ok: true, value: normalized };
  }

  return { ok: true, value: text };
};

const getMissingFollowupPropertyIds = (proposal, database) => {
  const requiredKeys = getAgentRequiredFieldKeys();
  const values = proposal?.values ?? {};

  return database.properties
    .filter((property) => {
      const key = normalizeKey(property.id);
      const nameKey = normalizeKey(property.name ?? '');
      const isConfigured =
        requiredKeys.includes(key) ||
        requiredKeys.includes(nameKey) ||
        (isLikelyTimeProperty(property) && requiredKeys.includes('uhrzeit'));
      const shouldRequire = Boolean(property.required) || isConfigured;
      if (!shouldRequire) return false;
      if (property.id === CARD_PROPERTY_IDS.status) return false;
      return isMissingValueForProperty(property, values[property.id]);
    })
    .map((property) => property.id);
};

const makePropertyAliasMap = (database) => {
  const map = new Map();
  const addAlias = (alias, propertyId) => {
    const key = normalizeKey(alias);
    if (!key) return;
    if (!map.has(key)) map.set(key, propertyId);
  };

  for (const property of database.properties) {
    addAlias(property.id, property.id);
    addAlias(property.name, property.id);
  }

  addAlias('titel', CARD_PROPERTY_IDS.title);
  addAlias('title', CARD_PROPERTY_IDS.title);
  addAlias('kunde', CARD_PROPERTY_IDS.title);
  addAlias('auftrag', CARD_PROPERTY_IDS.title);
  addAlias('status', CARD_PROPERTY_IDS.status);
  addAlias('phase', CARD_PROPERTY_IDS.status);
  addAlias('terminstatus', CARD_PROPERTY_IDS.status);
  addAlias('datum', CARD_PROPERTY_IDS.date);
  addAlias('termin', CARD_PROPERTY_IDS.date);
  addAlias('date', CARD_PROPERTY_IDS.date);
  addAlias('adresse', CARD_PROPERTY_IDS.address);
  addAlias('address', CARD_PROPERTY_IDS.address);
  addAlias('ort', CARD_PROPERTY_IDS.location);
  addAlias('location', CARD_PROPERTY_IDS.location);
  addAlias('stadt', CARD_PROPERTY_IDS.location);
  addAlias('telefon', CARD_PROPERTY_IDS.phone);
  addAlias('phone', CARD_PROPERTY_IDS.phone);
  addAlias('tel', CARD_PROPERTY_IDS.phone);
  addAlias('kommentar', '_comment');
  addAlias('notiz', '_comment');
  addAlias('quelle', '_source');

  return map;
};

const normalizeSchemaInput = (databaseInput, columns) => {
  if (!isObject(databaseInput)) return null;

  const rawProperties = Array.isArray(databaseInput.properties) ? databaseInput.properties : null;
  if (!rawProperties) return null;

  const normalizedProperties = [];
  const seen = new Set();
  for (const raw of rawProperties) {
    if (!isObject(raw)) continue;
    const rawId = typeof raw.id === 'string' ? raw.id : typeof raw.name === 'string' ? raw.name : '';
    const id = slugify(rawId);
    if (!id || seen.has(id)) continue;

    const type = ['text', 'select', 'date'].includes(raw.type) ? raw.type : 'text';
    const name = String(raw.name ?? id).trim() || id;
    const options =
      type === 'select' && Array.isArray(raw.options)
        ? Array.from(new Set(raw.options.map((option) => String(option).trim()).filter(Boolean)))
        : undefined;

    normalizedProperties.push({
      id,
      name,
      type,
      required: Boolean(raw.required),
      system: Boolean(raw.system),
      options,
    });
    seen.add(id);
  }

  const statuses = Object.keys(columns);
  const statusOptions = statuses.length ? statuses : DEFAULT_STATUS_ORDER;
  for (const required of DEFAULT_DATABASE.properties) {
    const idx = normalizedProperties.findIndex((property) => property.id === required.id);
    const base = {
      ...required,
      options: required.id === CARD_PROPERTY_IDS.status ? [...statusOptions] : required.options?.slice(),
    };
    if (idx < 0) {
      normalizedProperties.push(base);
      continue;
    }

    normalizedProperties[idx] = {
      ...normalizedProperties[idx],
      id: required.id,
      name: normalizedProperties[idx].name || required.name,
      type: required.type,
      required: Boolean(required.required),
      system: true,
      options: required.id === CARD_PROPERTY_IDS.status ? [...statusOptions] : normalizedProperties[idx].options,
    };
  }

  const orderedIds = [
    ...DEFAULT_DATABASE.properties.map((property) => property.id),
    ...normalizedProperties
      .map((property) => property.id)
      .filter((id) => !DEFAULT_DATABASE.properties.some((property) => property.id === id)),
  ];

  return {
    id: String(databaseInput.id ?? DEFAULT_DATABASE.id).trim() || DEFAULT_DATABASE.id,
    name: String(databaseInput.name ?? DEFAULT_DATABASE.name).trim() || DEFAULT_DATABASE.name,
    properties: orderedIds.map((id) => normalizedProperties.find((property) => property.id === id)).filter(Boolean),
  };
};

const findTimePropertyId = (database) => {
  const candidates = Array.isArray(database?.properties) ? database.properties : [];
  for (const property of candidates) {
    if (!property?.id) continue;
    if (property.id === CARD_PROPERTY_IDS.date || property.id === CARD_PROPERTY_IDS.status) continue;
    if (isLikelyTimeProperty(property)) {
      return property.id;
    }
  }
  return null;
};

const extractStructuredPairsFromLine = (line) => {
  const regex = /([A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß0-9 _/-]{0,40})\s*[:=]\s*/g;
  const matches = [];

  for (const match of line.matchAll(regex)) {
    const key = match[1]?.trim();
    const index = match.index;
    if (!key || typeof index !== 'number') continue;
    matches.push({
      key,
      valueStart: index + match[0].length,
      start: index,
    });
  }

  if (!matches.length) return [];

  return matches
    .map((entry, idx) => {
      const nextStart = idx + 1 < matches.length ? matches[idx + 1].start : line.length;
      const rawValue = line.slice(entry.valueStart, nextStart).replace(/^[,\s]+|[,\s]+$/g, '');
      return {
        key: entry.key,
        value: trimTrailingPunctuation(rawValue),
      };
    })
    .filter((pair) => pair.value.length > 0);
};

const extractIsoDateFromText = (text) => {
  const isoCandidate = /\b\d{4}-\d{2}-\d{2}\b/.exec(text)?.[0];
  if (isoCandidate) {
    const parsed = parseIsoDate(isoCandidate);
    if (parsed) return parsed;
  }

  const localCandidate = /\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b/.exec(text)?.[0];
  if (localCandidate) {
    const parsed = parseIsoDate(localCandidate);
    if (parsed) return parsed;
  }

  return null;
};

const extractTimeLabelFromText = (text) => {
  const raw = String(text ?? '');
  const hasTimeSignal = /(uhr|halb|viertel|dreiviertel|:\d{2}|[0-2]?\d\.[0-5]\d)/i.test(raw);
  if (!hasTimeSignal) return null;
  return normalizeTimeValue(raw);
};

const extractPhoneFromText = (text) => {
  const match = /(\+?\d[\d\s/()\-]{5,}\d)/.exec(text);
  return match ? match[1].replace(/\s+/g, ' ').trim() : null;
};

const extractLocationFromText = (text) => {
  const explicit = /\b(?:ort|stadt|location)\s*[:=]?\s*([A-Za-zÄÖÜäöüß][^,;\n.]*)/i.exec(text);
  if (!explicit) return null;
  const candidate = trimTrailingPunctuation(explicit[1]);
  if (!candidate) return null;
  return candidate.slice(0, 120);
};

const extractAddressFromText = (text) => {
  const explicit = /\b(?:adresse|anschrift)\s*[:=]?\s*([^;\n]+)/i.exec(text);
  if (explicit?.[1]) {
    const candidate = trimTrailingPunctuation(explicit[1]);
    if (candidate) return candidate.slice(0, 180);
  }

  const streetMatch =
    /\b([A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß0-9 .'-]{2,80}\b(?:straße|strasse|gasse|weg|platz|allee|ring|ufer|kai)\b(?:\s*\d+[a-zA-Z]?)?)/i.exec(
      text,
    );
  if (!streetMatch?.[1]) return null;
  return trimTrailingPunctuation(streetMatch[1]).slice(0, 180);
};

const guessTitleFromText = (text) => {
  const normalized = String(text ?? '').trim();
  if (!normalized) return null;

  const withoutTime = normalized.replace(/[,;]?\s*\b([01]?\d|2[0-3])(?:[:. ]([0-5]\d))?\s*uhr\b/gi, '');
  const collapsed = withoutTime.replace(/\s{2,}/g, ' ').trim();
  if (!collapsed) return null;

  return collapsed.slice(0, 140);
};

const findStatusFromText = (text, columns) => {
  const statuses = Object.keys(columns);
  if (!statuses.length) return null;
  const normalizedText = normalizeKey(text);
  if (!normalizedText) return null;

  for (const status of statuses) {
    if (normalizedText.includes(normalizeKey(status))) return status;
  }
  return null;
};

const parseFreeTextHints = (lines, titleLines, values, metadata, columns, database) => {
  const hints = {
    values: {},
    metadata: {},
    mapped: 0,
  };
  if (!lines.length) return hints;

  const mergedText = lines.join(' | ');
  const firstLine = titleLines[0] ?? '';

  if (!values[CARD_PROPERTY_IDS.title]) {
    const title = guessTitleFromText(firstLine);
    if (title) {
      hints.values[CARD_PROPERTY_IDS.title] = title;
      hints.mapped += 1;
    }
  }

  if (!values[CARD_PROPERTY_IDS.status]) {
    const status = findStatusFromText(mergedText, columns);
    if (status) {
      hints.values[CARD_PROPERTY_IDS.status] = status;
      hints.mapped += 1;
    }
  }

  if (!(CARD_PROPERTY_IDS.date in values)) {
    const isoDate = extractIsoDateFromText(mergedText);
    if (isoDate) {
      hints.values[CARD_PROPERTY_IDS.date] = isoDate;
      hints.mapped += 1;
    }
  }

  if (!(CARD_PROPERTY_IDS.phone in values)) {
    const phone = extractPhoneFromText(mergedText);
    if (phone) {
      hints.values[CARD_PROPERTY_IDS.phone] = phone;
      hints.mapped += 1;
    }
  }

  if (!(CARD_PROPERTY_IDS.location in values)) {
    const location = extractLocationFromText(mergedText);
    if (location) {
      hints.values[CARD_PROPERTY_IDS.location] = location;
      hints.mapped += 1;
    }
  }

  if (!(CARD_PROPERTY_IDS.address in values)) {
    const address = extractAddressFromText(mergedText);
    if (address) {
      hints.values[CARD_PROPERTY_IDS.address] = address;
      hints.mapped += 1;
    }
  }

  if (!metadata.comment) {
    const timeLabel = extractTimeLabelFromText(mergedText);
    if (timeLabel) {
      const timePropertyId = findTimePropertyId(database);
      if (timePropertyId && !(timePropertyId in values)) {
        hints.values[timePropertyId] = timeLabel;
      } else {
        hints.metadata.comment = `Uhrzeit: ${timeLabel}`;
      }
      hints.mapped += 1;
    }
  }

  return hints;
};

const parseMessageAgainstSchema = (text, database, columns) => {
  const normalizedText = String(text ?? '').trim();
  const lines = normalizedText
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const aliases = makePropertyAliasMap(database);
  const values = {};
  const metadata = {};
  const unmapped = [];
  let structuredLines = 0;
  let mappedLines = 0;
  const freeTextLines = [];
  const hintLines = [];

  const applyStructuredPair = (rawKey, rawValue) => {
    structuredLines += 1;
    const key = normalizeKey(rawKey);
    const normalizedRawValue = trimTrailingPunctuation(rawValue);
    if (!normalizedRawValue) return;
    hintLines.push(normalizedRawValue);
    const target = aliases.get(key);
    if (!target) {
      unmapped.push(`${rawKey}: ${normalizedRawValue}`);
      return;
    }

    if (target === '_comment') {
      metadata.comment = normalizedRawValue;
      mappedLines += 1;
      return;
    }

    if (target === '_source') {
      metadata.source = normalizedRawValue;
      mappedLines += 1;
      return;
    }

    const definition = database.properties.find((property) => property.id === target);
    if (!definition) return;
    mappedLines += 1;

    if (definition.type === 'date') {
      values[target] = parseIsoDate(normalizedRawValue) ?? extractIsoDateFromText(normalizedRawValue) ?? null;
      return;
    }

    if (definition.type === 'select') {
      const selectOptions =
        definition.id === CARD_PROPERTY_IDS.status
          ? Object.keys(columns)
          : Array.isArray(definition.options)
            ? definition.options
            : [];
      values[target] = parseSelectValue(normalizedRawValue, selectOptions);
      return;
    }

    values[target] = normalizedRawValue;
  };

  for (const line of lines) {
    const structuredPairs = extractStructuredPairsFromLine(line);
    if (!structuredPairs.length) {
      unmapped.push(line);
      freeTextLines.push(line);
      hintLines.push(line);
      continue;
    }
    for (const pair of structuredPairs) {
      applyStructuredPair(pair.key, pair.value);
    }
  }
  const hints = parseFreeTextHints(hintLines, freeTextLines, values, metadata, columns, database);
  Object.assign(values, hints.values);
  Object.assign(metadata, hints.metadata);
  const titleSeedLines = freeTextLines.length ? freeTextLines : structuredLines > 0 ? [] : lines;
  const finalizedValues = applyMandatoryValueDefaults(values, columns, titleSeedLines);
  const stats = { structuredLines, mappedLines, totalLines: lines.length, heuristicMatches: hints.mapped };
  const confidence = calculateRuleConfidence(stats, finalizedValues);

  return {
    values: finalizedValues,
    metadata,
    unmapped,
    confidence,
    extractionMode: 'rule',
    reasoning: `Rule parser matched ${mappedLines}/${Math.max(structuredLines, 1)} strukturierte Zeilen, Heuristiken: ${hints.mapped}.`,
    stats,
    lines,
  };
};

const isLlmConfigured = () => LLM_ENABLED && Boolean(OPENAI_API_KEY);

const buildLlmSchemaDescriptor = (database, columns) =>
  database.properties.map((property) => ({
    id: property.id,
    name: property.name,
    type: property.type,
    required: Boolean(property.required),
    options: property.type === 'select' ? getSelectOptionsForProperty(property, columns) : undefined,
  }));

const buildLlmExtractionPrompt = (text, database, columns, baseline) => {
  const schema = buildLlmSchemaDescriptor(database, columns);
  return [
    'Aufgabe: Extrahiere Service-/Termin-Daten aus Telegram-Text.',
    'Antwort nur als JSON-Objekt im exakten Format:',
    '{',
    '  "values": { "<propertyId>": "<value|null>" },',
    '  "metadata": { "comment": "<optional>", "source": "<optional>" },',
    '  "unmapped": ["<line>", "..."],',
    '  "confidence": 0.0-1.0,',
    '  "reasoning": "<kurz>"',
    '}',
    '',
    'Wichtige Regeln:',
    '- date strikt als ISO YYYY-MM-DD oder null.',
    '- select nur aus erlaubten options.',
    '- Fuer Uhrzeit-Felder Format "HH:mm Uhr".',
    '- Keine Halluzinationen; unsichere Teile in unmapped.',
    '- Deutschsprachige Spracheingabe mitdenken:',
    '  "morgen", "uebermorgen", "heute", "um drei", "halb drei", "viertel nach zwei", "viertel vor drei".',
    '',
    `Schema: ${JSON.stringify(schema)}`,
    `Statusoptionen: ${JSON.stringify(Object.keys(columns))}`,
    `Baseline: ${JSON.stringify({ values: baseline.values, metadata: baseline.metadata, unmapped: baseline.unmapped })}`,
    `Text:\n${text}`,
  ].join('\n');
};

const buildLlmRepairPrompt = (text, database, columns, baseline, previous) => {
  const schema = buildLlmSchemaDescriptor(database, columns);
  return [
    'Aufgabe: Repariere die Extraktion und verbessere Feldabdeckung, ohne zu halluzinieren.',
    'Antwort nur als JSON-Objekt im gleichen Format.',
    'Verbessere insbesondere fehlende Pflichtfelder und Datums-/Zeit-Normalisierung.',
    '',
    `Schema: ${JSON.stringify(schema)}`,
    `Statusoptionen: ${JSON.stringify(Object.keys(columns))}`,
    `Baseline: ${JSON.stringify({ values: baseline.values, metadata: baseline.metadata, unmapped: baseline.unmapped })}`,
    `Vorherige LLM-Ausgabe: ${JSON.stringify(previous)}`,
    `Originaltext:\n${text}`,
  ].join('\n');
};

const isFilledValue = (value) => {
  if (value === null || value === undefined) return false;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'string') return value.trim().length > 0;
  return true;
};

const countMissingRequiredFields = (values, database) =>
  database.properties.filter((property) => property.required && !isFilledValue(values[property.id])).length;

const scoreExtractionCandidate = (candidate, database) => {
  if (!candidate) return -1;
  const missingRequired = countMissingRequiredFields(candidate.values ?? {}, database);
  const filledCount = database.properties.filter((property) => isFilledValue(candidate.values?.[property.id])).length;
  const coverage = database.properties.length > 0 ? filledCount / database.properties.length : 0;
  return (candidate.confidence ?? 0) + coverage * 0.25 - missingRequired * 0.2;
};

const shouldRunRepairPass = (candidate, database) => {
  if (!candidate) return true;
  if (countMissingRequiredFields(candidate.values ?? {}, database) > 0) return true;
  return Number(candidate.confidence ?? 0) < LLM_REPAIR_MIN_CONFIDENCE;
};

const parseLlmCandidate = (rawContent, baseline, database, columns, extractionMode) => {
  const parsed = JSON.parse(rawContent);
  const metadata = parseMetadataFromRaw(parsed.metadata);
  const unmapped = toUnmappedArray(parsed.unmapped);
  const values = sanitizeValuesBySchema(parsed.values, baseline.values, database, columns, baseline.lines);
  const confidence = parseConfidence(parsed.confidence, Math.max(0.55, baseline.confidence));
  const reasoning =
    typeof parsed.reasoning === 'string' && parsed.reasoning.trim()
      ? parsed.reasoning.trim().slice(0, 280)
      : 'LLM-Extraktion ohne Begruendung.';

  return {
    values,
    metadata: { ...baseline.metadata, ...metadata },
    unmapped: Array.from(new Set([...baseline.unmapped, ...unmapped])),
    confidence,
    extractionMode,
    reasoning,
    stats: baseline.stats,
    lines: baseline.lines,
    raw: parsed,
  };
};

const llmChatJson = async (messages, signal) => {
  const response = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    signal,
    body: JSON.stringify({
      model: OPENAI_MODEL,
      temperature: 0,
      response_format: { type: 'json_object' },
      messages,
    }),
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`LLM request failed (${response.status}): ${detail}`);
  }

  const payload = await response.json();
  const rawContent = payload?.choices?.[0]?.message?.content;
  if (typeof rawContent !== 'string' || !rawContent.trim()) {
    throw new Error('LLM returned empty content.');
  }
  return rawContent;
};

const chooseByLlmStrategy = (baseline, llmCandidate) => {
  if (!llmCandidate) return null;
  if (LLM_STRATEGY === 'dominant') return llmCandidate;
  if (LLM_STRATEGY === 'hybrid') {
    if ((llmCandidate.confidence ?? 0) >= Math.max(0.3, (baseline?.confidence ?? 0) - 0.15)) return llmCandidate;
    return null;
  }

  if ((llmCandidate.confidence ?? 0) >= LLM_MIN_CONFIDENCE && (llmCandidate.confidence ?? 0) >= (baseline?.confidence ?? 0)) {
    return llmCandidate;
  }
  return null;
};

const callLlmExtraction = async (text, database, columns, baseline) => {
  if (!isLlmConfigured()) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LLM_TIMEOUT_MS);

  try {
    const systemMessage = { role: 'system', content: 'Du bist ein extrem praeziser Datenextraktor fuer Service-Projekte.' };
    const firstRaw = await llmChatJson(
      [
        systemMessage,
        { role: 'user', content: buildLlmExtractionPrompt(text, database, columns, baseline) },
      ],
      controller.signal,
    );

    let best = parseLlmCandidate(firstRaw, baseline, database, columns, 'llm_primary');

    if (LLM_REPAIR_PASS) {
      let tries = 0;
      while (tries < LLM_REPAIR_MAX_TRIES && shouldRunRepairPass(best, database)) {
        tries += 1;
        const repairRaw = await llmChatJson(
          [
            systemMessage,
            { role: 'user', content: buildLlmRepairPrompt(text, database, columns, baseline, best.raw ?? {}) },
          ],
          controller.signal,
        );

        const repaired = parseLlmCandidate(repairRaw, baseline, database, columns, 'llm_repair');
        if (scoreExtractionCandidate(repaired, database) >= scoreExtractionCandidate(best, database)) {
          best = repaired;
        }
      }
    }

    const chosen = chooseByLlmStrategy(baseline, best);
    if (!chosen) return null;

    return {
      ...chosen,
      extractionMode: LLM_STRATEGY === 'dominant' ? 'llm_dominant' : chosen.extractionMode,
      reasoning: `${chosen.reasoning} | strategy=${LLM_STRATEGY}`,
    };
  } catch (error) {
    console.error('LLM extraction failed, fallback to rule parser:', error);
    return null;
  } finally {
    clearTimeout(timeout);
  }
};

const describeValues = (values) =>
  Object.entries(values)
    .map(([key, value]) => `${key}: ${value === null ? '-' : String(value)}`)
    .join('\n');

const normalizeTelegramSource = (value) => {
  const normalized = normalizeKey(value);
  if (!normalized) return APP_DEFAULTS.fallbackSource;
  if (normalized.includes('whatsapp')) return 'WhatsApp';
  return 'E-Mail';
};

const buildTelegramMessageKey = (proposal) => {
  if (!proposal || proposal.chatId === undefined || proposal.messageId === undefined) return '';
  return `${proposal.chatId}:${proposal.messageId}`;
};

const buildTelegramImportKey = (proposal) => {
  if (!proposal) return '';
  const parts = [
    String(proposal.chatId ?? ''),
    normalizeKey(proposal.values?.[CARD_PROPERTY_IDS.title] ?? ''),
    String(proposal.values?.[CARD_PROPERTY_IDS.date] ?? ''),
    normalizeKey(proposal.values?.[CARD_PROPERTY_IDS.address] ?? ''),
    normalizeKey(proposal.values?.[CARD_PROPERTY_IDS.location] ?? ''),
    normalizeKey(proposal.values?.[CARD_PROPERTY_IDS.phone] ?? ''),
    normalizeKey(proposal.values?.[CARD_PROPERTY_IDS.status] ?? ''),
  ];
  const key = parts.join('|');
  if (key.replace(/\|/g, '').length > 0) return key;
  return `${String(proposal.chatId ?? '')}|${normalizeKey(proposal.rawText ?? '')}`;
};

const findDuplicateCardForProposal = (proposal, board) => {
  const messageKey = buildTelegramMessageKey(proposal);
  const importKey = buildTelegramImportKey(proposal);

  for (const card of Object.values(board.cardsById ?? {})) {
    if (!card || card.hiddenAt) continue;
    if (messageKey && card.telegramMessageKey === messageKey) return card;
    if (importKey && card.telegramImportKey === importKey) return card;
  }

  return null;
};

const createCardFromProposal = (proposal, board) => {
  const now = toNowIso();
  const id = randomId('card');
  const status = String(proposal.values[CARD_PROPERTY_IDS.status] ?? APP_DEFAULTS.fallbackStatus);
  const title = String(proposal.values[CARD_PROPERTY_IDS.title] ?? APP_DEFAULTS.newCardTitle).trim() || APP_DEFAULTS.newCardTitle;
  const address = String(proposal.values[CARD_PROPERTY_IDS.address] ?? '').trim();
  const location = String(proposal.values[CARD_PROPERTY_IDS.location] ?? '').trim();
  const phone = String(proposal.values[CARD_PROPERTY_IDS.phone] ?? '').trim();
  const date = proposal.values[CARD_PROPERTY_IDS.date] ?? null;
  const source = normalizeTelegramSource(proposal.metadata.source);

  const values = {
    ...proposal.values,
    [CARD_PROPERTY_IDS.title]: title,
    [CARD_PROPERTY_IDS.status]: status,
    [CARD_PROPERTY_IDS.address]: address,
    [CARD_PROPERTY_IDS.location]: location,
    [CARD_PROPERTY_IDS.phone]: phone,
    [CARD_PROPERTY_IDS.date]: date,
    [CARD_PROPERTY_IDS.sources]: [source],
  };

  const comments = [];
  if (proposal.metadata.comment) {
    comments.push({
      id: randomId('c'),
      user: APP_DEFAULTS.actorName,
      text: String(proposal.metadata.comment).slice(0, 2000),
      createdAt: now,
    });
  }

  const card = {
    id,
    title,
    collapsed: false,
    status,
    sources: [source],
    address,
    location,
    phone,
    date,
    hiddenAt: null,
    values,
    comments,
    history: [],
    createdAt: now,
    updatedAt: now,
    telegramMessageKey: buildTelegramMessageKey(proposal),
    telegramImportKey: buildTelegramImportKey(proposal),
  };

  if (!Array.isArray(board.columns[status])) board.columns[status] = [];
  board.columns[status].push(id);
  board.cardsById[id] = card;
  return card;
};

const toWorkspacePayload = (board) => ({
  formatVersion: 2,
  exportedAt: toNowIso(),
  board: {
    schemaVersion: 2,
    cardsById: board.cardsById,
    columns: board.columns,
    database: board.database,
  },
  database: board.database,
  ui: {
    dashboardLabel: APP_DEFAULTS.dashboardLabel,
    dashboardSubtitle: APP_DEFAULTS.dashboardSubtitle,
  },
});

const filterBoardSince = (board, sinceIso) => {
  if (!sinceIso) return board;
  const sinceMs = Date.parse(sinceIso);
  if (!Number.isFinite(sinceMs)) return board;

  const nextCardsById = {};
  for (const [cardId, card] of Object.entries(board.cardsById ?? {})) {
    const updatedMs = Date.parse(card?.updatedAt ?? card?.createdAt ?? '');
    if (!Number.isFinite(updatedMs)) continue;
    if (updatedMs <= sinceMs) continue;
    nextCardsById[cardId] = card;
  }

  const nextColumns = {};
  for (const [status, cardIds] of Object.entries(board.columns ?? {})) {
    nextColumns[status] = Array.isArray(cardIds) ? cardIds.filter((cardId) => Boolean(nextCardsById[cardId])) : [];
  }

  return {
    ...board,
    cardsById: nextCardsById,
    columns: nextColumns,
  };
};

const tgApi = async (method, payload) => {
  if (!BOT_TOKEN) return null;

  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Telegram API ${method} failed: ${response.status} ${text}`);
  }

  return response.json();
};

const ensureDataDir = async () => {
  if (!existsSync(DATA_DIR)) {
    await mkdir(DATA_DIR, { recursive: true });
  }
};

const loadState = async () => {
  await ensureDataDir();
  if (!existsSync(STATE_PATH)) return createDefaultState();

  try {
    const raw = await readFile(STATE_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return ensureStateShape(parsed);
  } catch (error) {
    console.error('Failed to load state, fallback to defaults:', error);
    return createDefaultState();
  }
};

let state = await loadState();

const persistState = async () => {
  await ensureDataDir();
  await writeFile(STATE_PATH, JSON.stringify(state, null, 2), 'utf8');
};

const addAudit = (type, payload) => {
  const event = {
    id: randomId('audit'),
    type,
    at: toNowIso(),
    ...payload,
  };
  state.audit.unshift(event);
  if (state.audit.length > 500) state.audit = state.audit.slice(0, 500);
};

const isImportBlockedByGuardrail = (confidence) => Number(confidence ?? 0) < IMPORT_GUARDRAIL_CONFIDENCE;

const buildProposalKeyboard = (proposalId, confidence) => {
  if (isImportBlockedByGuardrail(confidence)) {
    return {
      inline_keyboard: [
        [
          { text: 'Nachbearbeiten', callback_data: `tg:edit:${proposalId}` },
          { text: 'Verwerfen', callback_data: `tg:no:${proposalId}` },
        ],
      ],
    };
  }

  return {
    inline_keyboard: [
      [
        { text: 'Importieren', callback_data: `tg:ok:${proposalId}` },
        { text: 'Verwerfen', callback_data: `tg:no:${proposalId}` },
      ],
    ],
  };
};

const renderEditTemplate = (proposal, database) => {
  const lines = database.properties.map((property) => {
    const value = proposal.values?.[property.id];
    const rendered = value === null || value === undefined ? '' : Array.isArray(value) ? value.join(', ') : String(value);
    return `${property.name}: ${rendered}`;
  });

  if (proposal.metadata?.comment) lines.push(`Kommentar: ${proposal.metadata.comment}`);
  if (proposal.metadata?.source) lines.push(`Quelle: ${proposal.metadata.source}`);

  return lines.join('\n');
};

const renderProposalText = (proposal) => {
  const warningLine = proposal.unmapped.length ? `\nNicht zugeordnet: ${proposal.unmapped.join(' | ')}` : '';
  const confidencePct = Math.round((proposal.confidence ?? 0) * 100);
  const usedLlm = String(proposal.extractionMode ?? '').startsWith('llm');
  const confidenceLine = `Extraktion: ${usedLlm ? 'LLM' : 'Rule'} | Confidence: ${confidencePct}%`;
  const lowConfidenceLine =
    proposal.confidence < LLM_MIN_CONFIDENCE
      ? `Achtung: niedrige Sicherheit (< ${Math.round(LLM_MIN_CONFIDENCE * 100)}%). Bitte vor Import pruefen.`
      : '';
  const guardrailLine = isImportBlockedByGuardrail(proposal.confidence)
    ? `Guardrail aktiv: Unter ${Math.round(IMPORT_GUARDRAIL_CONFIDENCE * 100)}% ist direkter Import gesperrt.`
    : '';
  return [
    'Neue Vorlage erkannt.',
    confidenceLine,
    proposal.reasoning ? `Hinweis: ${proposal.reasoning}` : '',
    lowConfidenceLine,
    guardrailLine,
    '',
    describeValues(proposal.values),
    warningLine,
    '',
    `Proposal-ID: ${proposal.id}`,
    'Importieren?',
  ]
    .filter(Boolean)
    .join('\n');
};

const getConversationKey = (chatId) => String(chatId ?? '');

const sendProposalPreview = async (proposal) => {
  if (!proposal?.chatId) return;
  const keyboard = buildProposalKeyboard(proposal.id, proposal.confidence);
  const sent = await tgApi('sendMessage', {
    chat_id: proposal.chatId,
    text: renderProposalText(proposal),
    reply_markup: keyboard,
  });

  if (sent?.ok && sent?.result?.message_id && state.pending[proposal.id]) {
    state.pending[proposal.id].previewMessageId = sent.result.message_id;
    await persistState();
  }
};

const renderFollowupQuestion = (property, remaining) => {
  const base = `Bitte ${property.name} angeben.`;
  if (property.type === 'date') {
    return `${base}\nFormat: TT.MM.JJJJ oder YYYY-MM-DD (auch "morgen", "heute").\nOffen: ${remaining}`;
  }
  if (isLikelyTimeProperty(property)) {
    return `${base}\nFormat: 15:00, 15 Uhr, halb drei, viertel nach zwei.\nOffen: ${remaining}`;
  }
  if (property.type === 'select' && Array.isArray(property.options) && property.options.length > 0) {
    return `${base}\nOptionen: ${property.options.join(' | ')}\nOffen: ${remaining}`;
  }
  return `${base}\nOffen: ${remaining}`;
};

const askNextFollowupQuestion = async (chatId) => {
  const conversation = state.conversations?.[getConversationKey(chatId)];
  if (!conversation) return false;
  const proposal = state.pending?.[conversation.proposalId];
  if (!proposal) {
    delete state.conversations[getConversationKey(chatId)];
    await persistState();
    return false;
  }

  const nextPropertyId = conversation.missingPropertyIds?.[0];
  if (!nextPropertyId) {
    delete state.conversations[getConversationKey(chatId)];
    await persistState();
    await sendProposalPreview(proposal);
    return true;
  }

  const property = state.board.database.properties.find((entry) => entry.id === nextPropertyId);
  if (!property) {
    conversation.missingPropertyIds = getMissingFollowupPropertyIds(proposal, state.board.database);
    conversation.updatedAt = toNowIso();
    await persistState();
    return askNextFollowupQuestion(chatId);
  }

  conversation.lastAskedPropertyId = property.id;
  conversation.updatedAt = toNowIso();
  await persistState();

  await tgApi('sendMessage', {
    chat_id: chatId,
    text: renderFollowupQuestion(property, conversation.missingPropertyIds.length),
  });
  return true;
};

const maybeStartFollowupConversation = async (proposal) => {
  if (!AGENT_ENABLED) return false;
  const missingPropertyIds = getMissingFollowupPropertyIds(proposal, state.board.database);
  if (!missingPropertyIds.length) return false;

  const chatId = proposal.chatId;
  state.conversations[getConversationKey(chatId)] = {
    proposalId: proposal.id,
    startedAt: toNowIso(),
    updatedAt: toNowIso(),
    missingPropertyIds,
    lastAskedPropertyId: null,
  };
  addAudit('telegram_agent_followup_started', {
    actor: proposal.from?.id ? `telegram:${proposal.from.id}` : 'telegram:unknown',
    chatId,
    proposalId: proposal.id,
    missingPropertyIds,
  });
  await persistState();
  await askNextFollowupQuestion(chatId);
  return true;
};

const handleFollowupAnswer = async (message, text) => {
  const chatId = message?.chat?.id;
  if (!chatId) return false;
  const conversation = state.conversations?.[getConversationKey(chatId)];
  if (!conversation) return false;

  const proposal = state.pending?.[conversation.proposalId];
  if (!proposal) {
    delete state.conversations[getConversationKey(chatId)];
    await persistState();
    return false;
  }

  const targetPropertyId = conversation.missingPropertyIds?.[0];
  if (!targetPropertyId) {
    delete state.conversations[getConversationKey(chatId)];
    await persistState();
    await sendProposalPreview(proposal);
    return true;
  }

  const property = state.board.database.properties.find((entry) => entry.id === targetPropertyId);
  if (!property) {
    conversation.missingPropertyIds = getMissingFollowupPropertyIds(proposal, state.board.database);
    conversation.updatedAt = toNowIso();
    await persistState();
    await askNextFollowupQuestion(chatId);
    return true;
  }

  const parsed = parseValueForProperty(property, text, state.board.columns);
  if (!parsed.ok) {
    await tgApi('sendMessage', {
      chat_id: chatId,
      text: parsed.message ?? `Wert fuer ${property.name} konnte nicht gelesen werden. Bitte erneut angeben.`,
    });
    await askNextFollowupQuestion(chatId);
    return true;
  }

  proposal.values[property.id] = parsed.value;
  if (property.id === CARD_PROPERTY_IDS.title) {
    proposal.values[CARD_PROPERTY_IDS.title] = String(parsed.value ?? '').trim() || APP_DEFAULTS.newCardTitle;
  }

  if (property.type === 'date') {
    const timePropertyId = findTimePropertyId(state.board.database);
    if (timePropertyId && isMissingValueForProperty({ type: 'text' }, proposal.values[timePropertyId])) {
      const maybeTime = normalizeTimeValue(text);
      if (maybeTime) proposal.values[timePropertyId] = maybeTime;
    }
  }

  if (isLikelyTimeProperty(property)) {
    const maybeDate = parseIsoDate(text) ?? extractIsoDateFromText(text);
    if (maybeDate && isMissingValueForProperty({ type: 'date' }, proposal.values[CARD_PROPERTY_IDS.date])) {
      proposal.values[CARD_PROPERTY_IDS.date] = maybeDate;
    }
  }

  conversation.missingPropertyIds = getMissingFollowupPropertyIds(proposal, state.board.database);
  conversation.updatedAt = toNowIso();
  addAudit('telegram_agent_followup_answered', {
    actor: message.from?.id ? `telegram:${message.from.id}` : 'telegram:unknown',
    chatId,
    proposalId: proposal.id,
    propertyId: property.id,
  });

  if (!conversation.missingPropertyIds.length) {
    delete state.conversations[getConversationKey(chatId)];
    addAudit('telegram_agent_followup_completed', {
      actor: message.from?.id ? `telegram:${message.from.id}` : 'telegram:unknown',
      chatId,
      proposalId: proposal.id,
    });
    await persistState();
    await sendProposalPreview(proposal);
    return true;
  }

  await persistState();
  await askNextFollowupQuestion(chatId);
  return true;
};

const renderTelegramTemplate = (database, columns) => {
  const statuses = Object.keys(columns);
  const defaultStatus = statuses.includes(APP_DEFAULTS.fallbackStatus) ? APP_DEFAULTS.fallbackStatus : statuses[0] ?? '';
  const fields = Array.isArray(database?.properties)
    ? database.properties
        .map((property) => String(property?.name ?? '').trim())
        .filter(Boolean)
        .filter((name) => normalizeKey(name) !== 'status')
    : ['Titel', 'Datum', 'Ort', 'Adresse', 'Telefon'];

  const lines = ['Vorlage fuer neue Anfrage:', ''];
  for (const field of fields) lines.push(`${field}:`);
  lines.push('Kommentar:');
  lines.push(`Status: ${defaultStatus}`);
  lines.push('');
  lines.push('Du kannst auch Freitext senden, z. B.:');
  lines.push('Termin: morgen 15 Uhr, Ort: Lienz, Adresse: Peter Weber Gasse, Datum: 19.02.2026');
  return lines.join('\n');
};

const renderTelegramHelp = () =>
  [
    'Verfuegbare Kommandos:',
    '/neu - Vorlage zum Ausfuellen',
    '/beispiel - Beispieltexte',
    '/abbrechen - Rueckfragen beenden',
    '/hilfe - Diese Hilfe',
    '',
    'Tipp: Spracheingabe ist okay. Nutze moeglichst Schluesselwoerter wie',
    'Titel, Datum, Uhrzeit, Ort, Adresse, Telefon, Kommentar, Status.',
  ].join('\n');

const renderTelegramExamples = (columns) => {
  const statuses = Object.keys(columns);
  const defaultStatus = statuses.includes(APP_DEFAULTS.fallbackStatus) ? APP_DEFAULTS.fallbackStatus : statuses[0] ?? '';

  return [
    'Beispiele:',
    '',
    `1) Strukturierte Vorlage`,
    `Titel: Fensterbank Montage`,
    `Datum: 19.02.2026`,
    `Uhrzeit: 15:00`,
    `Ort: Lienz`,
    `Adresse: Peter Weber Gasse`,
    `Telefon: +43 660 1234567`,
    `Status: ${defaultStatus}`,
    '',
    `2) Freitext`,
    `Termin: morgen 15 Uhr, Ort: Lienz, Adresse: Peter Weber Gasse, Datum: 19.02.2026`,
  ].join('\n');
};

const parseTelegramCommand = (text) => {
  const match = /^\/([a-z0-9_]+)(?:@[\w_]+)?(?:\s+(.*))?$/i.exec(String(text ?? '').trim());
  if (!match) return null;
  return {
    name: match[1].toLowerCase(),
    args: match[2] ?? '',
  };
};

const handleTelegramCommand = async (message, text) => {
  if (!message?.chat?.id) return false;
  const parsed = parseTelegramCommand(text);
  if (!parsed) return false;

  const command = parsed.name;
  const chatKey = getConversationKey(message.chat.id);
  const conversation = state.conversations?.[chatKey];
  let replyText = '';

  if (['abbrechen', 'cancel', 'stop'].includes(command)) {
    if (!conversation) {
      replyText = 'Kein aktiver Rueckfrage-Flow vorhanden.';
    } else {
      const proposal = state.pending?.[conversation.proposalId];
      delete state.conversations[chatKey];
      addAudit('telegram_agent_followup_cancelled', {
        actor: `telegram:${message.from?.id ?? 'unknown'}`,
        chatId: message.chat.id,
        proposalId: conversation.proposalId,
      });
      await persistState();
      if (proposal) {
        await sendProposalPreview(proposal);
        replyText = 'Rueckfragen beendet. Vorschau wurde erneut gesendet.';
      } else {
        replyText = 'Rueckfragen beendet.';
      }
    }
  } else if (['start', 'hilfe', 'help'].includes(command)) {
    replyText = renderTelegramHelp();
  } else if (['neu', 'new'].includes(command)) {
    replyText = renderTelegramTemplate(state.board.database, state.board.columns);
  } else if (['beispiel', 'example'].includes(command)) {
    replyText = renderTelegramExamples(state.board.columns);
  } else {
    replyText = `Unbekanntes Kommando: /${command}\nNutze /hilfe fuer die verfuegbaren Kommandos.`;
  }

  addAudit('telegram_command_received', {
    actor: `telegram:${message.from?.id ?? 'unknown'}`,
    chatId: message.chat.id,
    messageId: message.message_id,
    command,
  });
  await persistState();

  await tgApi('sendMessage', {
    chat_id: message.chat.id,
    text: replyText,
  });
  return true;
};

const handleMessageUpdate = async (message) => {
  if (!message?.chat?.id) return;
  if (!Number.isInteger(message.message_id)) return;
  const text = typeof message.text === 'string' ? message.text.trim() : '';
  if (!text) return;

  if (text.startsWith('/')) {
    const handled = await handleTelegramCommand(message, text);
    if (handled) return;
  }

  const handledAsFollowup = await handleFollowupAnswer(message, text);
  if (handledAsFollowup) return;

  const existingPending = Object.values(state.pending).find(
    (proposal) => proposal.chatId === message.chat.id && proposal.messageId === message.message_id,
  );
  if (existingPending) return;

  const parsed = parseMessageAgainstSchema(text, state.board.database, state.board.columns);
  const llmParsed = await callLlmExtraction(text, state.board.database, state.board.columns, parsed);
  const extracted = llmParsed ?? parsed;
  const proposalId = randomId('proposal');

  const proposal = {
    id: proposalId,
    createdAt: toNowIso(),
    chatId: message.chat.id,
    messageId: message.message_id,
    from: message.from
      ? {
          id: message.from.id,
          username: message.from.username ?? null,
          firstName: message.from.first_name ?? null,
        }
      : null,
    rawText: text,
    values: extracted.values,
    metadata: extracted.metadata,
    unmapped: extracted.unmapped,
    confidence: extracted.confidence,
    extractionMode: extracted.extractionMode,
    reasoning: extracted.reasoning,
    previewMessageId: null,
  };

  state.pending[proposalId] = proposal;
  addAudit('telegram_proposal_created', {
    actor: `telegram:${message.from?.id ?? 'unknown'}`,
    proposalId,
    chatId: message.chat.id,
    messageId: message.message_id,
    extractionMode: proposal.extractionMode,
    confidence: proposal.confidence,
  });
  await persistState();

  const followupStarted = await maybeStartFollowupConversation(proposal);
  if (followupStarted) return;

  await sendProposalPreview(proposal);
};

const handleCallbackQuery = async (query) => {
  const callbackId = query?.id;
  const data = typeof query?.data === 'string' ? query.data : '';
  const chatId = query?.message?.chat?.id;
  const messageId = query?.message?.message_id;
  const actor = query?.from?.id ? `telegram:${query.from.id}` : 'telegram:unknown';

  if (!callbackId || !data) return;
  const match = /^tg:(ok|no|edit):([a-z0-9_]+)$/i.exec(data);
  if (!match) {
    await tgApi('answerCallbackQuery', { callback_query_id: callbackId, text: 'Ungueltige Aktion.' });
    return;
  }

  const action = match[1];
  const proposalId = match[2];
  const proposal = state.pending[proposalId];
  if (!proposal) {
    await tgApi('answerCallbackQuery', { callback_query_id: callbackId, text: 'Proposal nicht gefunden.' });
    return;
  }

  if (action === 'edit') {
    const template = renderEditTemplate(proposal, state.board.database);
    delete state.pending[proposalId];
    addAudit('telegram_proposal_edit_requested', {
      actor,
      proposalId,
      chatId: proposal.chatId,
      extractionMode: proposal.extractionMode,
      confidence: proposal.confidence,
    });
    await persistState();

    if (chatId && messageId) {
      await tgApi('editMessageText', {
        chat_id: chatId,
        message_id: messageId,
        text: `Proposal ${proposalId} zur Nachbearbeitung markiert.\nBitte korrigierte Vorlage neu senden:\n\n${template}`,
      });
    }
    await tgApi('answerCallbackQuery', {
      callback_query_id: callbackId,
      text: 'Bitte Vorlage korrigieren und neu senden.',
    });
    return;
  }

  if (action === 'no') {
    delete state.pending[proposalId];
    addAudit('telegram_proposal_rejected', {
      actor,
      proposalId,
      chatId: proposal.chatId,
      extractionMode: proposal.extractionMode,
      confidence: proposal.confidence,
    });
    await persistState();

    if (chatId && messageId) {
      await tgApi('editMessageText', {
        chat_id: chatId,
        message_id: messageId,
        text: `Proposal ${proposalId} wurde verworfen.`,
      });
    }
    await tgApi('answerCallbackQuery', { callback_query_id: callbackId, text: 'Verworfen.' });
    return;
  }

  const activeConversation = Object.values(state.conversations ?? {}).find(
    (conversation) => conversation?.proposalId === proposalId && Array.isArray(conversation?.missingPropertyIds),
  );
  if (activeConversation && activeConversation.missingPropertyIds.length > 0) {
    await tgApi('answerCallbackQuery', {
      callback_query_id: callbackId,
      text: 'Bitte zuerst Rueckfragen abschliessen.',
    });
    if (proposal.chatId) {
      await askNextFollowupQuestion(proposal.chatId);
    }
    return;
  }

  if (isImportBlockedByGuardrail(proposal.confidence)) {
    await tgApi('answerCallbackQuery', {
      callback_query_id: callbackId,
      text: `Import gesperrt unter ${Math.round(IMPORT_GUARDRAIL_CONFIDENCE * 100)}%. Bitte Nachbearbeiten.`,
    });
    return;
  }

  const duplicate = findDuplicateCardForProposal(proposal, state.board);
  if (duplicate) {
    delete state.pending[proposalId];
    addAudit('telegram_import_deduplicated', {
      actor,
      proposalId,
      cardId: duplicate.id,
      chatId: proposal.chatId,
      extractionMode: proposal.extractionMode,
      confidence: proposal.confidence,
    });
    await persistState();

    if (chatId && messageId) {
      await tgApi('editMessageText', {
        chat_id: chatId,
        message_id: messageId,
        text: `Bereits vorhanden als Karte ${duplicate.id}\nTitel: ${duplicate.title}\nStatus: ${duplicate.status}`,
      });
    }
    await tgApi('answerCallbackQuery', { callback_query_id: callbackId, text: 'Bereits importiert.' });
    return;
  }

  const card = createCardFromProposal(proposal, state.board);
  delete state.pending[proposalId];
  addAudit('telegram_import_confirmed', {
    actor,
    proposalId,
    cardId: card.id,
    chatId: proposal.chatId,
    extractionMode: proposal.extractionMode,
    confidence: proposal.confidence,
  });
  await persistState();

  if (chatId && messageId) {
    await tgApi('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text: `Importiert als Karte ${card.id}\nTitel: ${card.title}\nStatus: ${card.status}`,
    });
  }
  await tgApi('answerCallbackQuery', { callback_query_id: callbackId, text: 'Importiert.' });
};

const handleTelegramWebhook = async (req, res) => {
  if (WEBHOOK_SECRET) {
    const header = req.headers['x-telegram-bot-api-secret-token'];
    if (header !== WEBHOOK_SECRET) {
      sendJson(res, 401, { ok: false, error: 'Invalid webhook secret.' });
      return;
    }
  }

  let payload;
  try {
    const raw = await readBody(req);
    payload = raw ? JSON.parse(raw) : {};
  } catch (error) {
    sendJson(res, 400, { ok: false, error: `Invalid JSON: ${String(error)}` });
    return;
  }

  const updateId = Number.isInteger(payload.update_id) ? payload.update_id : null;
  if (updateId !== null && updateId <= state.lastUpdateId) {
    sendJson(res, 200, { ok: true, dedup: true });
    return;
  }

  try {
    if (payload.message || payload.channel_post) {
      await handleMessageUpdate(payload.message ?? payload.channel_post);
    } else if (payload.callback_query) {
      await handleCallbackQuery(payload.callback_query);
    } else {
      addAudit('telegram_webhook_ignored', {
        actor: 'system',
        reason: 'unsupported_update_type',
        keys: Object.keys(payload ?? {}),
      });
      await persistState();
    }

    if (updateId !== null) {
      state.lastUpdateId = updateId;
      await persistState();
    }

    sendJson(res, 200, { ok: true });
  } catch (error) {
    console.error('Webhook processing failed:', error);
    addAudit('telegram_webhook_error', {
      actor: 'system',
      message: error instanceof Error ? error.message : String(error),
    });
    await persistState();
    sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
  }
};

const handleBoardSchemaUpdate = async (req, res) => {
  let payload;
  try {
    const raw = await readBody(req);
    payload = raw ? JSON.parse(raw) : {};
  } catch (error) {
    sendJson(res, 400, { ok: false, error: `Invalid JSON: ${String(error)}` });
    return;
  }

  const candidate = isObject(payload) && isObject(payload.database) ? payload.database : payload;
  const normalized = normalizeSchemaInput(candidate, state.board.columns);
  if (!normalized) {
    sendJson(res, 400, { ok: false, error: 'Invalid database schema payload.' });
    return;
  }

  state.board.database = normalized;
  addAudit('board_schema_updated', {
    actor: 'client',
    propertyCount: normalized.properties.length,
  });
  await persistState();
  sendJson(res, 200, { ok: true, database: normalized });
};

const server = http.createServer(async (req, res) => {
  const method = req.method ?? 'GET';
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? `localhost:${PORT}`}`);

  if (method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-telegram-bot-api-secret-token');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.end();
    return;
  }

  if (method === 'GET' && url.pathname === '/api/health') {
    sendJson(res, 200, {
      ok: true,
      service: 'telegram-mvp',
      botConfigured: Boolean(BOT_TOKEN),
      llmEnabled: LLM_ENABLED,
      llmConfigured: isLlmConfigured(),
      llmModel: OPENAI_MODEL,
      llmStrategy: LLM_STRATEGY,
      llmRepairPass: LLM_REPAIR_PASS,
      llmRepairMinConfidence: LLM_REPAIR_MIN_CONFIDENCE,
      agentEnabled: AGENT_ENABLED,
      importGuardrailConfidence: IMPORT_GUARDRAIL_CONFIDENCE,
      pendingProposals: Object.keys(state.pending).length,
      openConversations: Object.keys(state.conversations ?? {}).length,
    });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/board/state') {
    const since = url.searchParams.get('since');
    sendJson(res, 200, toWorkspacePayload(filterBoardSince(state.board, since)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/board/schema') {
    await handleBoardSchemaUpdate(req, res);
    return;
  }

  if (method === 'GET' && url.pathname === '/api/board/audit') {
    const limit = Math.max(1, Math.min(200, Number(url.searchParams.get('limit') ?? 50)));
    sendJson(res, 200, { ok: true, items: state.audit.slice(0, limit) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/telegram/pending') {
    sendJson(res, 200, { ok: true, items: Object.values(state.pending) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/telegram/conversations') {
    sendJson(res, 200, { ok: true, items: Object.values(state.conversations ?? {}) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/telegram/webhook') {
    await handleTelegramWebhook(req, res);
    return;
  }

  sendJson(res, 404, { ok: false, error: 'Not found' });
});

server.listen(PORT, HOST, () => {
  console.log(`Telegram MVP server listening on http://${HOST}:${PORT}`);
  console.log(`Import guardrail threshold: ${Math.round(IMPORT_GUARDRAIL_CONFIDENCE * 100)}%`);
  console.log(
    `LLM strategy: ${LLM_STRATEGY} | repairPass=${LLM_REPAIR_PASS} | repairMinConfidence=${Math.round(
      LLM_REPAIR_MIN_CONFIDENCE * 100,
    )}%`,
  );
  if (!BOT_TOKEN) {
    console.warn('TELEGRAM_BOT_TOKEN is not set. Webhook will parse requests but cannot reply in Telegram.');
  }
  if (LLM_ENABLED && !OPENAI_API_KEY) {
    console.warn('LLM_ENABLED is true but OPENAI_API_KEY is missing. Falling back to rule parser.');
  }
});
