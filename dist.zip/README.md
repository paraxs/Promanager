# ProManager

Kanban-basiertes Service- und Termin-Management fuer Projekte.

## Features

- Konfigurierbarer Dashboard-Titel und Untertitel
- Kanban-Workflow mit Statuswechsel, Historie und Kommentaren
- Karten einklappen (mobile-optimiert)
- Archiv mit Wiederherstellen
- JSON Export/Import inkl. UI-Einstellungen
- PDF Export (A4, druckoptimiert)

## Voraussetzungen

- Node.js 20+
- npm 10+

## Lokale Entwicklung

```bash
npm install
npm run dev
```

App startet standardmaessig unter `http://localhost:5173`.

## Telegram MVP (Webhook + Confirm-Flow)

### 1) API-Server starten

```bash
npm run server:dev
```

Der Server laeuft standardmaessig auf `http://localhost:8787`.
`npm run server:dev` laedt automatisch Variablen aus `.env`.

### 2) Umgebungsvariablen

Nutze `.env.example` als Vorlage:

- `TELEGRAM_BOT_TOKEN` (von BotFather)
- `TELEGRAM_WEBHOOK_SECRET` (frei waehlbarer Secret-Header)
- `TELEGRAM_MVP_PORT` (optional, default `8787`)
- `TELEGRAM_MVP_HOST` (optional, default `0.0.0.0`)
- `LLM_ENABLED` (`1` oder `0`)
- `LLM_MIN_CONFIDENCE` (z. B. `0.70`)
- `LLM_STRATEGY` (`dominant` | `hybrid` | `fallback`, default `dominant`)
- `LLM_REPAIR_PASS` (`1` oder `0`, default `1`)
- `LLM_REPAIR_MIN_CONFIDENCE` (z. B. `0.82`)
- `LLM_REPAIR_MAX_TRIES` (`1` bis `3`, default `2`)
- `AGENT_ENABLED` (`1` oder `0`, default `1`)
- `AGENT_REQUIRED_FIELDS` (CSV, z. B. `date,location,address,uhrzeit`)
- `IMPORT_GUARDRAIL_CONFIDENCE` (z. B. `0.65`, darunter kein direkter Import)
- `OPENAI_API_KEY` (wenn LLM aktiviert)
- `OPENAI_BASE_URL` (OpenAI-kompatible API, default `https://api.openai.com/v1`)
- `OPENAI_MODEL` (z. B. `gpt-4.1-mini`)
- `LLM_TIMEOUT_MS` (optional, default `12000`)

### 3) Webhook bei Telegram setzen

Beispiel:

```bash
curl "https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/setWebhook?url=<PUBLIC_URL>/api/telegram/webhook&secret_token=<TELEGRAM_WEBHOOK_SECRET>"
```

### 4) Ablauf

1. Nachricht im Bot senden (Vorlage mit `Feld: Wert`)
2. Rule-Parser extrahiert Felder nach `database.properties`
3. Optional (wenn aktiviert): LLM verfeinert Extraktion mit Confidence-Score
4. Bei `LLM_STRATEGY=dominant`: AI-Ergebnis ist primaer, Rule-Parser bleibt Fallback
5. Optionaler Repair-Pass korrigiert niedrige Confidence oder fehlende Felder
6. Optional Agent-Flow stellt Rueckfragen zu fehlenden Feldern (z. B. Datum/Ort/Adresse/Uhrzeit)
7. Bot antwortet mit Vorschau + Confidence
8. Guardrail:
   - confidence >= `IMPORT_GUARDRAIL_CONFIDENCE`: `Importieren` / `Verwerfen`
   - confidence < `IMPORT_GUARDRAIL_CONFIDENCE`: `Nachbearbeiten` / `Verwerfen`
9. Bei `Nachbearbeiten` sendet der Bot eine editierbare Vorlage, die erneut geschickt wird
10. Bei `Importieren` wird eine Karte persistent gespeichert
11. Audit-Event wird geschrieben
12. Im Dashboard: `Menue -> Telegram Sync`

Bot-Kommandos:

- `/neu` -> sendet eine Ausfuell-Vorlage
- `/beispiel` -> sendet Beispieltexte
- `/abbrechen` -> beendet aktive Rueckfragen
- `/hilfe` oder `/start` -> Hilfe

### 5) Relevante API-Endpunkte

- `POST /api/telegram/webhook`
- `GET /api/board/state`
- `POST /api/board/schema`
- `GET /api/board/audit`
- `GET /api/telegram/pending`
- `GET /api/telegram/conversations`
- `GET /api/health`

### 6) Lokale Smoke-Tests

```bash
npm run test:telegram:smoke
npm run test:telegram:guardrail
npm run test:telegram:command
npm run test:telegram:schema
npm run test:telegram:agent
```

- `test:telegram:smoke`: Message -> Proposal -> `Importieren` -> Card + Audit
- `test:telegram:guardrail`: niedrige Confidence -> `tg:ok` wird serverseitig blockiert

### 7) Telegram State Reset (optional)

```bash
npm run server:reset-state
```

- erstellt ein Backup von `server/data/state.json`
- setzt den Telegram-Serverzustand zurueck (Board/Pending/Audit)

## Qualitaetssicherung

```bash
npm run lint
npm run test
npm run build
```

## Datenhaltung

- Board-Daten werden lokal gespeichert (`localStorage`)
- Dashboard-Beschriftung und Untertitel werden ebenfalls lokal gespeichert
- JSON-Backups enthalten Board + UI-Einstellungen
- Telegram-MVP persistiert serverseitig unter `server/data/state.json` (Board, Pending-Proposals, Audit)
